package com.yurakcompany.techservice.notification.api;

public class BusinessNotificationsController {
}
